#pragma once
#include <iostream>
#include "Transport.h"
using namespace std;

class Account
{
protected:
    string NAME;
    string ID;
    string PASSWORD;
    double Surplus;
    double IDmonth = 20082000;
public:
    Account();
    Account(string, string, string, double);
    bool SigIn(string, string);
    bool setIDM(double);
    double getSurplus()const;
    void addMoney(double);
    void subtractionMoney(Transport *, double);
    ~Account();
};

Account::Account()
{
    this->NAME="";
    this->ID="";
    this->PASSWORD="";
    this->Surplus=0;
}

Account::Account(string name, string id, string password, double surplus)
{
    this->NAME=name;
    this->ID=id;
    this->PASSWORD=password;
    this->Surplus=surplus;
}

bool Account::setIDM(double idm)
{
    if (idm == this->IDmonth)
        return true;
    return false;
}

double Account::getSurplus()const
{
    return this->Surplus;
}

bool Account::SigIn(string id, string password)
{
    if (id == this->ID && password == this->PASSWORD)
        return true;
    return false;
}

void Account::addMoney(double money)
{
    if (money>0)
        this->Surplus = this->Surplus + money;
}

void Account::subtractionMoney(Transport *A, double idm)
{
    if (setIDM(idm)==true)
        this->Surplus = this->Surplus - (A->Price()*0.8);
    else
        this->Surplus = this->Surplus - A->Price();
}

Account::~Account()
{}