#include <iostream>
#include "Transport.h"
#include "Bus.h"
#include "Metro.h"
#include "Bicycle.h"
#include "Account.h"
using namespace std;

int main()
{
    Transport *BMW[10000];
    for (int i=0; i<5; i++)
    {
        double idm;
        double surplus;
        /*string name;
        string id;
        string password;
        double surplus;
        cout<<"Moi ban nhap ho va ten: ";
        cin.ignore();
        getline(cin,name);
        cout<<"Moi ban nhap ID: ";
        cin.ignore();
        getline(cin,id);
        cout<<"Moi ban nhap Password: ";
        cin.ignore();
        getline(cin,password);*/
        cout<<"Moi ban nhap so du: ";
        cin>>surplus;
        Account A("a", "Axxxxx", "******", surplus);
        cout<<"Nhap ma ve thang: ";
        cin>>idm;
        int n;
        cout<<"Quang duong da di bang xe bus: ";
        cin>>n;
        Bus bus(n);
        int m;
        cout<<"Quang duong da di bang xe metro: ";
        cin>>m; 
        Metro metro(m);
        int k;
        cout<<"Quang duong da di bang xe dap (nhap so gio da di): ";
        cin>>k;
        Bicycle bicycle(k);
        BMW[0] = &bus;
        BMW[1] = &metro;
        BMW[2] = &bicycle;
        A.subtractionMoney(BMW[0],idm);
        A.subtractionMoney(BMW[1],idm);
        A.subtractionMoney(BMW[2],idm);
        cout<<"So tien con lai la: ";
        cout<<A.getSurplus()<<endl;
        cout<<endl;
    }
    return 0;
} 